%{ Specifying the Axes or Figure }%

function myfunction(x)
% Evaluate the expression using the input argumenty = 1.5*cos(x) + 6*exp(-.1*x) + exp(.07*x).*sin(3*x);
% Calculate the mean
y = 1.5*cos(x) + 6*exp(-.1*x) + exp(.07*x).*sin(3*x);
ym = mean(y);
% Create a figure, axes parented to that axes
% and the using the axes
hfig = figure('Name','Function and Mean');
hax = axes('Parent',hfig);
plot(hax,x,y)
% Hold the current plot and add a red line along the mean value
hold on
plot(hax,[min(x) max(x)],[ym ym],'Color','red')
hold off
% Add a tick label that shows the mean value
% and add a title and axis labels
ylab = get(hax,'YTick');
set(hax,'YTick',sort([ylab ym]))
title ('y = 1.5cos(x) + 6e^{-0.1x} + e^{0.07x}sin(3x)')
xlabel('X Axis'); ylabel('Y Axis')
end