%{ define matrix A %}
A = [16 3 2 13;
     5 10 11 8;
     9 6 7 12;
     4 15 14 1];
 
%{ ---------------------------------------- %}

%{ excludes the variable name from the output %}
disp(sum(A))
%{ uses the formatting string on each element of the variable %}
fprintf('A matrix\n')
disp(A)
fprintf('A matrix %i\n', A)

%{ ---------------------------------------- %}

%{ transposes matrix %}
fprintf('A matrix\n')
disp(A')
fprintf('Transpose A matrix %i\n', A')

%{ ---------------------------------------- %} 
disp(sum(A')');

%{ sum of the elements on the main diagonal is obtained with the sum %}
 disp(diag(A))
 disp(sum(diag(A)))
 
%{fliplr, flips a matrix from left to right, to get the sum of the antidiagonal %}
disp(sum(diag(fliplr(A))))


disp(A(4,2)) %{element in 4th row and second column%}

%{subscripts | compute the sum of the elements in the fourth column of A%}
disp(A(1,4) + A(2,4) + A(3,4) + A(4,4))

B = A; 
B(4,5) = 17;

%{ colon operator %}
disp(1:10)
%{ specify an increment }%
disp(100:-10:0)
disp(pi:-pi/4:0)

%{ the end keyword refers to the last row or column (depending on the position of the matrix%}
disp(sum(A(:,end)))
 
%{ magic sum of  4-by-4 square }%
disp(sum(1:16)/4)

%{ the magic function:  creates magic squares of almost any size }%
B = magic(4);
%{ switch order of columns}%
A = B(:,[1 3 2 4]);

num_students = 25;
%{ MATLAB uses only the first N characters of the name }%
N = namelengthmax;

%{ numbers }%
x = 36028797018963968;
y = 36028797018963972;
x = y;

%{ Integers have available precisions of 8-bit, 16-bit, 32-bit, and 64-bit}&
%{ Storing the same numbers as 64-bit integers preserves precision }%
x = uint64(36028797018963968);
y = uint64(36028797018963972);
x = y;

sort([3+4i, 4+3i])
angle(3+4i)
angle(4+3i)

%{ operators }%

%{ functions }%
%{ overwrite any function }%
eps = 1.e-6;

%{ restore function }%
clear eps


%{ Examples of Expressions }%
rho = (1+sqrt(5))/2;
rho = 1.6180;

a = abs(3+4i);
a = 5;

help besselk
%{ Modified Bessel function of the second kind %}
z = sqrt(besselk(4/3,rho-1i));
z = 0.3730 + 0.3214i;

huge = exp(log(realmax));
huge = 1.7977e+308;

toobig = pi*huge;
toobig = Inf;

%{ Working with Matrices }%
%{ Generating Matrices }%
Z = zeros(2,4);
F = 5*ones(3,3);
N = fix(10*rand(1,10));
R = randn(4,4);

%{ The load Function }%
%{ reads the file and creates a variable, magik , containing the example matrix }%
load magik.dat

%{ Saving Code to a File }%
magik

%{ Concatenation }%
B = [A A+32; A+48 A+16];
sum(B)

%{ Deleting Rows and Columns }%
X = A;
%{ delete the second column of X }% 
X(:,2) = [];
%{ using single subscript %}
X(2:2:10)
X(2:2:10) = [];

%{ Linear Algebra }%
%{ D�rer�s magic square }%
A = [16 3 2 13
     5 10 11 8
     9 6 7 12
     4 15 14 1];

%{ Adding a matrix to its transpose produces a symmetric matrix }%
A + A';
%{ * , denotes the matrix multiplication involving inner products between rows and columns.}%
%{ Multiplying the transpose of a matrix by the original matrix also produces a symmetric matrix}%
A'*A;

%{ The determinant of this particular matrix happens to be zero %}
d = det(A);

%{ reduced row echelon form of A is not the identity %}
R = rref(A);

%{ Because the matrix is singular, it does not have an inverse. If you try to %}
%{ compute the inverse with %}
X = inv(A);

%{  eigenvalues of the magic square %}
e = eig(A);
v = ones(4,1);
A*v;

%{  magic square is scaled by its magic sum %}
P = A/34;
%{ as approaches infinity, all the elements in the th power, approach . %} 
P^5;

%{ returns the coefficients of the characteristic polynomial %}
poly(A)

%{ Arrays }%
%{ Building Tables }%
A.*A;
n = (0:9)';
pows = [n n.^2 2.^n];

format short g
x = (1:0.1:2)';
logs = [x log10(x)];

%{ Multivariate Data }%
D = [ 72 134 3.2
        81 201 3.5
        69 156 7.1
        82 148 2.4
        75 170 1.2 ];

mu = mean(D); sigma = std(D);    
help datafun
help stats

%{ Scalar Expansion  }%
%{ forms a matrix whose column sums are zero %}
B = A - 8.5;
sum(B)

B(1:2,2:3) = 0;

%{ Logical Subscripting }%
x = [2.1 1.7 1.6 1.5 NaN 1.9 1.8 1.5 5.1 1.8 1.4 2.2 1.6 1.8];
%{  To remove the missing data with logical indexing, %}
%{ use isfinite(x) which is true for all finite numerical values and false for %}
%{ NaN and Inf :%}
x = x(isfinite(x));

%{ 5.1 is an outlier, so to remove outliers that are more than 3 standard deviations from the mean %}
x = x(abs(x-mean(x)) <= 3*std(x));

%{ highlight the location of the prime numbers in D�rer�s }%
%{ magic square by using logical indexing and scalar expansion to set the }%
%{ nonprimes to 0 %}
A;
A(~isprime(A)) = 0;


%{ The find Function }%
%{ picks out the locations, using one-dimensional indexing, of the primes in the magic square %}
k = find(isprime(A))';
A(k);
A(k) = NaN;

%{ The format Function }%
x = [4/3 1.2345e-6];
format short
format short e
format short g
format long
format long e
format long g
format bank
format rat
format hex
%{ suppresses many of the blank lines that appear in the output %}
format compact

%{ Suppressing Output }%
A = magic(100);

%{ Entering Long Statements }%
%{  use an ellipsis (three periods), ... , %}
%{ followed by Return or Enter to indicate that the statement continues on %}
%{ the next line %}
s = 1 -1/2 + 1/3 -1/4 + 1/5 - 1/6 + 1/7 ...
- 1/8 + 1/9 - 1/10 + 1/11 - 1/12;

%{ Command Line Editing }%
rho = (1 + sqrt(5))/2;




