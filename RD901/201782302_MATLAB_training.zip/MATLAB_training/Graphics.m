%{ Creating Graphs with the Plot Selector }%
figurepalette
plotbrowser
propertyeditor

%{  Using Plotting Tools and MATLAB Code  }%
t = 0:pi/20:2*pi;
y = exp(sin(t));
plotyy(t,y,t,y,'plot','stem')
xlabel('X Axis')
ylabel('Plot Y Axis')

area(t,y,'DisplayName','t,y');figure(gcf)
inspect(gca)

%{ Plotting Two Variables with Plotting Tools }%

x = -1:.1:1; % Define the range of x
y = x.^3; % Raise each element in x to the third power
plottools

%{ Modifying the Graph Data Source }%
%{ 1. Define 50 points between -3? and 3? and compute their sines and cosines %}
x = linspace(-3*pi,3*pi,50);
ys = sin(x);
yc = cos(x);
%{ 2 Using the plotting tools, create a graph of ys = sin(x) }%
figure
plottools

%{ Providing New Values for the Data Source }%
x = linspace(-pi,pi,50); % Define 50 points between - and
y = sin(x);
area(x,y) % Make an area plot of x and y

%{  recalculation y %}
y = cos(x);

%{ Annotating Graphs }%
x = -10:.005:40;
y = [1.5*cos(x)+4*exp(-.01*x).*cos(x)+exp(.07*x).*sin(3*x)];
plot(x,y)


%{  add text annotations, axis labels, and a title }%
title ('y = 1.5cos(x) + 4e^{-0.01x}cos(x) + e^{0.07x}sin(3x)')
xlabel('X Axis')
ylabel('Y Axis')

%{ Creating a Plot }%

x = 0:pi/100:2*pi;
y = sin(x);
plot(x,y)

%{ label the axes and add a title }%
xlabel('x = 0:2\pi')
ylabel('Sine of x')

title('Plot of the Sine Function','FontSize',12)

%{ Plotting Multiple Data Sets in One Graph }%
x = 0:pi/100:2*pi;
y = sin(x);
y2 = sin(x-.25);
y3 = sin(x-.5);
plot(x,y,x,y2,x,y3)

%{ legend command provides an easy way to identify the individual plots}%
legend('sin(x)','sin(x-.25)','sin(x-.5)')

%{ Specifying Line Styles and Colors }% 
%{ plot(x,y,'color_style_marker') %}

%{ Plotting Lines and Markers }%

plot(x,y,'ks')
plot(x,y,'r:+')


%{ Placing Markers at Every Tenth Data Point }%
x1 = 0:pi/100:2*pi;
x2 = 0:pi/10:2*pi;
plot(x1,sin(x1),'r:',x2,sin(x2),'r+')

%{ Graphing Imaginary and Complex Data }%
% plot(Z)
% plot(real(Z),imag(Z))
% t = 0:pi/10:2*pi;
% plot(exp(1i*t),'-o')
% axis equal

%{ Adding Plots to an Existing Graph }%
%{a contour plot of the peaks function then superimpose a pseudocolor plot of the same function %}
[x,y,z] = peaks;
pcolor(x,y,z)
shading interp
hold on
contour(x,y,z,20,'k')
hold off
%{figure(n)%}
%{Clearing the Figure for a New Plot }%
clf reset

%{ Displaying Multiple Plots in One Figure }%
%{ subplot(m,n,p) %}

t = 0:pi/10:2*pi;
[X,Y,Z] = cylinder(4*cos(t));
subplot(2,2,1); mesh(X)
subplot(2,2,2); mesh(Y)
subplot(2,2,3); mesh(Z)
subplot(2,2,4); mesh(X,Y,Z)

%{ Controlling the Axes }%
%{ Setting Axis Limits }%
axis square
axis equal

%{ Setting the Axis Aspect Ratio }%
plot(exp(1i*[0:pi/10:2*pi]))
axis auto normal

%{ Setting Axis Visibility }%
axis on
axis off

%{ Setting Grid Lines }%
grid on
grid off

%{ Adding Axis Labels and Titles }%
t = -pi:pi/100:pi;
y = sin(t);
plot(t,y)
axis([-pi pi -1 1])
xlabel('-\pi \leq {\itt} \leq \pi')
ylabel('sin(t)')
title('Graph of the sine function')
text(1,-1/3,'{\itNote the odd symmetry.}')

%{ Visualizing Functions of Two Variables }%
%{ Adding Axis Labels and Titles }%

%{ Example � Graphing the sinc Function }%
[X,Y] = meshgrid(-8:.5:8);
R = sqrt(X.^2 + Y.^2) + eps;
Z = sin(R)./R;
mesh(X,Y,Z,'EdgeColor','black')

%{ Example � Colored Surface Plots }%
surf(X,Y,Z)
colormap hsv
colorbar

%{ Making Surfaces Transparent }%
surf(X,Y,Z)
colormap hsv
alpha(.4)

%{ Illuminating Surface Plots with Lights }%
surf(X,Y,Z,'FaceColor','red','EdgeColor','none')
camlight left; lighting phong

%{ About Plotting Image Data }%
image(X)
%{ colormap(map) %}
axis image
load detail
colormap(hot)

%{ Using the Print Command }%
print -depsc2 -tiff magicsquare.eps
print -dtiff -r200 magicsquare.tiff

%{ Understanding Handle Graphics Objects }%
figure('Color','white','Toolbar','none')

%{ Using the Handle }%
x = 1:10;
y = x.^3;
h = plot(x,y);
set(h,'Color','red')
h = plot(x,y,'Color','red');
get(h,'LineWidth')
get(h)

%{ Setting Properties from Plotting Commands }%
%{ surf(x,y,z,'FaceColor','interp','FaceLighting','gouraud') %}

%{ Setting Properties of Existing Objects }%
h = plot(magic(5));
set(h,'Marker','s','MarkerFaceColor','g')

%{ Setting Multiple Property Values }%
h = plot(magic(5));
prop_name(1) = {'Marker'};
prop_name(2) = {'MarkerFaceColor'};

prop_values(1,1) = {'s'};
prop_values(1,2) = {get(h(1),'Color')};
prop_values(2,1) = {'d'};
prop_values(2,2) = {get(h(2),'Color')};
prop_values(3,1) = {'o'};
prop_values(3,2) = {get(h(3),'Color')};
prop_values(4,1) = {'p'};
prop_values(4,2) = {get(h(4),'Color')};
prop_values(5,1) = {'h'};
prop_values(5,2) = {get(h(5),'Color')};

set(h,prop_name,prop_values)

x = -10:.005:40;
myfunction(x)

%{ Finding All Objects of a Certain Type }%
h = findobj('Type','patch');

%{ Finding Objects with a Particular Property }%
h = findobj('Type','line','Color','r','LineStyle',':');

%{ Limiting the Scope of the Search }%
h = findobj(gca,'Type','text','String','\pi/2');

%{ Using findobj as an Argument }%
set(findobj('Type','line','Color','red'),'LineStyle',':')


