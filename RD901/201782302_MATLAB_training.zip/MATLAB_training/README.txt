I installed the VPN Access Manager and the version MATLAB R2016a for windows from the 
recommended software provided from the University of Strathclyde (UoS), in order to use MATLAB.  
									
This folder contains various scripts that calculate different metrics, multiple graph-examples exported 
from MATLAB to pdf format and a simple gui example. The material for the online course provided by UoS
was accessed from the SharePoint platform provided from the UoS and can be found in the following links.
  
https://moss.strath.ac.uk/developmentandtraining/resourcecentre/Pages/MATLAB.aspx .
https://bookings.strath.ac.uk/Home/Bookings

This course, has given me insight into the capabilities of the multi-paradigm numerical computing environment 
MATLAB. The official handbook guide, helped me explore a variety of aspects of this software tool, including 
a variety of data structures and when to use them, programming with MATLAB, the ready-to-use statistical 
functions, how to construct my own function, graphics,  the data analysis techniques (e.g. vectorization),  the 
Gui provided by MATLAB which has very similal elements to the Swing library for the Java language. Furthermore,
I studied various youtube videos provided from the official MATLAB youtube channel, which gives further 
helpful information regarding the available software.