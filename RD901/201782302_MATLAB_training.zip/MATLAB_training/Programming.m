% Conditional Control � if, else, switch


% Generate a random number
a = randi(100, 1);
% If it is even, divide by 2
if rem(a, 2) == 0
disp('a is even')
b = a/2;
end


a = randi(100, 1);
if a < 30
disp('small')
elseif a < 80
disp('medium')
else
disp('large')
end


[dayNum, dayString] = weekday(date, 'long', 'en_US');
switch dayString
case 'Monday'
disp('Start of the work week')
case 'Tuesday'
disp('Day 2')
case 'Wednesday'
disp('Day 3')
case 'Thursday'
disp('Day 4')
case 'Friday'
disp('Last day of the work week')
otherwise
disp('Weekend!')
end


yourNumber = input('Enter a number: ');
if yourNumber < 0
disp('Negative')
elseif yourNumber > 0
disp('Positive')
else
disp('Zero')
end

%{ Array Comparisons in Conditional Statements }%
A = magic(4); B = A; B(1,1) = 0;

A == B

if isequal(A, B)
    disp('True')
end


if A > B
'greater'
elseif A < B
'less'
elseif A == B
disp('equal')
else
% error('Unexpected situation')
disp('Unexpected situation')
end
    
%{ Loop Control � for, while, continue, break }%
for n = 3:32
r(n) = rank(magic(n));
end
r

m = 5
n = 5

for i = 1:m
for j = 1:n
H(i,j) = 1/(i+j);
end
end

% testing a while loop
a = 0; fa = -Inf;
b = 3; fb = Inf;
while b-a > eps*b
x = (a+b)/2;
fx = x^3-2*x-5;
if sign(fx) == sign(fa)
a = x; fa = fx;
else
b = x; fb = fx;
end
end
x;


% continue
fid = fopen('magic.m','r');
count = 0;
while ~feof(fid)
line = fgetl(fid);
if isempty(line) || strncmp(line,'%',1) || ~ischar(line)
continue
end
count = count + 1;
end
fprintf('%d lines\n',count);
fclose(fid);


%{ break }%
a = 0; fa = -Inf;
b = 3; fb = Inf;
while b-a > eps*b
x = (a+b)/2;
fx = x^3-2*x-5;
if fx == 0
break
elseif sign(fx) == sign(fa)
a = x; fa = fx;
else
b = x; fb = fx;
end
end
x;

%{ Error Control � try, catch }%
% try
%statement
%...
%statement
%catch exceptObj
%statement
%...
%statement
%end 


% Multidimensional Arrays
R = randn(3,4,5);
p = perms(1:4);
A = magic(4);
M = zeros(4,4,24);
d = 2;
for k = 1:24
M(:,:,k) = A(:,p(k,:));
end
size(M) 
sum(M,d)
sum(M,1)
sum(M,2)
S = sum(M,3)


% Cell Arrays
C = {A sum(A) prod(prod(A))}
M = cell(8,1);
for n = 1:8
M{n} = magic(n);
end
M;

M{4};

% Characters and Text
s = 'Hello';
a = double(s);
s = char(a);
F = reshape(32:127,16,6)';
char(F)
char(F+128)
h = [s, ' world']
v = [s; 'world'];
S = char('A','rolling','stone','gathers','momentum.');
C = {'A';'rolling';'stone';'gathers';'momentum.'};
C = cellstr(S);
S = char(C);



% Structures
% O.name = 'Ed Plum';
% O.score = 83;
% O.grade = 'B+'

O(2).name = 'Toni Miller';
O(2).score = 91;
O(2).grade = 'A-';

O(3) = struct('name','Jerry Garcia','score',70,'grade','C');

scores = [O.score]; 

avg_score = sum(scores)/length(scores);

names = char(O.name);

names = {O.name};

[N1, N2] = O.name;

% Dynamic Field Names
%structName.(expression)
%structName.(expression)(7,1:25)


% Dynamic Field Names Examples
testscores.Ann_Lane.week(1:25) = ...
[95 89 76 82 79 92 94 92 89 81 75 93 ...
85 84 83 86 85 90 82 82 84 79 96 88 98];

testscores.William_King.week(1:25) = ...
[87 80 91 84 99 87 93 87 97 87 82 89 ...
86 82 90 98 75 79 92 84 90 93 84 78 81];

avgscore(testscores, 'Ann_Lane', 7, 22)
avgscore(testscores, 'William_King', 7, 22)

% Scripts
% Investigate the rank of magic squares
r = zeros(1,32);
for n = 3:32
r(n) = rank(magic(n));
end
r;
bar(r)

% magicrank
% Functions
rank(A)
r = rank(A);
r = rank(A,1.e-6);

% Anonymous Functions
f = @(arglist)expression;
sqr = @(x) x.^2;
a = sqr(5)

% Nested Functions
%function x = A(p1, p2)
%...
%B(p2)
%function y = B(p3)
%...
%end
%...
%end

% Global Variables


global GRAVITY
GRAVITY = 32;
y = falling((0:.1:5)');

% Passing String Arguments to Functions
% Constructing String Arguments in Code
% for d = 1:31
% s = ['August' int2str(d) '.dat'];
% load(s)
% Code to process the contents of the d-th file
% end

% The eval Function
% for d = 1:31
% s = ['load August' int2str(d) '.dat'];
% eval(s)
% Process the contents of the d-th file
% end


% Function Handles
% Function Functions
% fhandle = @sin;
%function plot_fhandle(fhandle, data)
%plot(data, fhandle(data))
%end
% plot(-pi:0.01:pi)
% Vectorization

% Function Functions
x = 0:.002:1;
y = humps(x);
plot(x,y)
p = fminsearch(@humps,.5)
humps(p)
Q = quadl(@humps,0,1)
z = fzero(@humps,.5)


% Vectorization
x = .01;
for k = 1:1001
y(k) = log10(x);
x = x + .01;
end

x = .01:.01:10;
y = log10(x);

% Preallocation
r = zeros(32,1);
for n = 1:32
r(n) = rank(magic(n));
end
